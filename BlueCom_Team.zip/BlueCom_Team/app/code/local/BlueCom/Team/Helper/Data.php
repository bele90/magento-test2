<?php
class BlueCom_Team_Helper_Data
    extends Mage_Core_Helper_Abstract
{
}