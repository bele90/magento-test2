<?php
class BlueCom_Team_Model_Department
    extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {  
        $this->_init('bluecom_team/department');
    }  
}